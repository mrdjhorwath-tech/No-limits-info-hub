
# No Limits Info Hub — Repo-Ready (Cards + Netlify Functions)

This repo is ready to deploy on Netlify **with serverless functions enabled** so your **Upcoming Events** show as clickable cards.

## Folder layout
```
index.html
/assets
  logo.png
  pit-schedule.pdf
  palm-schedule.pdf
  student-handbook.pdf
  pno-register.html
/netlify/functions
  ics.js
netlify.toml
```

The page fetches your Google Calendar feed via the function at:
```
/.netlify/functions/ics?url=https%3A%2F%2Fcalendar.google.com%2Fcalendar%2Fical%2F3e51a6301fe688400bab1734bd7a40587d841334eb26cbdbbfc3bcfa63f1e065%2540group.calendar.google.com%2Fpublic%2Fbasic.ics
```
If that URL returns **200 OK** with ICS text, your cards will render.

---

## Deploy Option 1 — Netlify (Import from GitHub) ✅ Recommended
1. Create a new repo on GitHub (e.g., `no-limits-info-hub`).
2. Upload **all files** from this folder to the new repo (preserve the `/netlify/functions` and `/assets` folders).
3. In Netlify: **Add new site → Import from Git** → choose that GitHub repo.
4. Netlify auto-detects `netlify/functions` from `netlify.toml` and enables functions.
5. Open your site. You should now see **Upcoming Events** as **cards**.

**Verify functions are live:**
Navigate to:
```
https://YOUR-SITE.netlify.app/.netlify/functions/ics?url=https%3A%2F%2Fcalendar.google.com%2Fcalendar%2Fical%2F3e51a6301fe688400bab1734bd7a40587d841334eb26cbdbbfc3bcfa63f1e065%2540group.calendar.google.com%2Fpublic%2Fbasic.ics
```
You should see raw ICS text. If so, functions are good.

---

## Deploy Option 2 — Netlify CLI
If you prefer a quick terminal deploy:

```bash
# One-time install
npm install -g netlify-cli

# In this repo directory
netlify login
netlify init    # create or link the site
netlify deploy --dir="." --functions="netlify/functions" --prod
```

Then visit your site and confirm the cards render.

---

## Calendar description link
Paste this in your Google Calendar event description (first line):
```
Register & Pay: https://test-hub-2.netlify.app/assets/pno-register.html
```

## Customize
- To switch the placeholder to Stripe/Eventbrite, edit:
  - `assets/pno-register.html` → replace the button link when you’re ready.
- The placeholder page uses a **lighter navy** box for the description for readability.
